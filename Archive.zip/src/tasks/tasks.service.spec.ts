// import { Test } from '@nestjs/testing';
// import { TaskRepository } from './task.repository';
// import { TasksService } from './tasks.service';

// const mockTestRepository = () => ({});

// describe('taskService', () => {
//   let taskService;
//   let taskRepository;

//   beforeEach(async () => {
//     const module = await Test.createTestingModule({
//       providers: [
//         TasksService,
//         { provide: TaskRepository, useFactory: mockTestRepository },
//       ],
//     }).compile();

//     taskService = await module.get(TasksService);
//     taskRepository = await module.get(TaskRepository);
//   });
// });
